# Mobile_Data_Collection

For Easy instlation i added Application instlation Folder, just download the APK file and install it inside your phone. 


I'm Working this weak on(1) Saving the stream inside the application,
                         (2)controlling the arduino and giving sleep mode
                         (3)experminting with MySql Lite database
                        
