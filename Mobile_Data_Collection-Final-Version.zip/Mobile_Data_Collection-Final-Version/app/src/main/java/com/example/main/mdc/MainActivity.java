package com.example.main.mdc;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.UUID;
import java.io.File;
import android.os.Handler;

public class MainActivity extends Activity {

	private static final String TAG = "BlueTest5-MainActivity";

	private String deviceAddress = "";
	private int mMaxChars = 500000000;//Default
	private UUID mDeviceUUID;
	private BluetoothSocket mBTSocket;
	private ReadInput mReadThread = null;
	private boolean mIsUserInitiatedDisconnect = false;

	// All controls here
	private TextView mTxtReceive;
	private EditText mEditSend;
	private Button mBtnDisconnect;
	private Button mBtnSend;
	private Button mBtnClear;
	private Button mBtnClearInput;
	private ScrollView scrollView;
	private CheckBox chkScroll;
	private CheckBox chkReceiveText;
	private int progress;




	DatabaseHelper mydb;
    //EditText ed;

	ProgressDialog progressBar;
	private int progressBarStatus = 0;

	private boolean mIsBluetoothConnected = false;
	private Handler progressBarbHandler = new Handler();

	private BluetoothDevice mDevice;

	private ProgressDialog progressDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		Button btnRequest, btnStop, btnCollect, btnServer;
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ActivityHelper.initialize(this);

        mydb = new DatabaseHelper(this);


		btnRequest = (Button) findViewById(R.id.buttonRequest);
		btnStop = (Button) findViewById(R.id.buttonStop);
		btnCollect = (Button) findViewById(R.id.buttonCollect);
		btnServer = (Button) findViewById(R.id.buttonServer);
		Intent intent = getIntent();
		Bundle b = intent.getExtras();
		mDevice = b.getParcelable(Homescreen.DEVICE_EXTRA);
		mDeviceUUID = UUID.fromString(b.getString(Homescreen.DEVICE_UUID));
		mMaxChars = b.getInt(Homescreen.BUFFER_SIZE);

		Log.d(TAG, "Ready");

		mBtnDisconnect = (Button) findViewById(R.id.btnDisconnect);



		deviceAddress = mDevice.getAddress();

		mBtnDisconnect.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mIsUserInitiatedDisconnect = true;
				new DisConnectBT().execute();
			}
		});

		btnRequest.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Cursor c = mydb.getAllData();
				String str ="";
				long epochTime =0;
				ByteBuffer buffer = ByteBuffer.allocate(8);
				long count = (c.getCount());
				if(count == 0){
					buffer.putLong(0);
				} else{
					c.moveToLast();
					str = (c.getString(c.getColumnIndex("SYNC")));

					buffer.putLong(Long.parseLong(str));
				}

				int[] dataRequestPacketPart1 = {0x00, 0x01, 0x02, 0x03}; //Version 0, Type 1 - DataRequest, Checksum, Reserved
				int[] dataRequestPacketPart2 = {0x00, 8, 0x00, 0x00}; //16bit length (in this case its saying 3 bytes), 16 bit reserved
                int[] dataRequestPacketPart3 = {buffer.get(0), buffer.get(1), buffer.get(2), buffer.get(3)}; //16bit length (in this case its saying 3 bytes), 16 bit reserved
                int[] dataRequestPacketPart4 = {buffer.get(4), buffer.get(5), buffer.get(6), buffer.get(7)}; //16bit length (in this case its saying 3 bytes), 16 bit reserved
				byte[] msgBuffer1 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer1[i] = (byte)dataRequestPacketPart1[i];
				}
				byte[] msgBuffer2 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer2[i] = (byte)dataRequestPacketPart2[i];
				}
				byte[] msgBuffer3 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer3[i] = (byte)dataRequestPacketPart3[i];
				}
				byte[] msgBuffer4 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer4[i] = (byte)dataRequestPacketPart4[i];
				}
				try {
					mBTSocket.getOutputStream().write(msgBuffer1);
					mBTSocket.getOutputStream().write(msgBuffer2);
					mBTSocket.getOutputStream().write(msgBuffer3);
					mBTSocket.getOutputStream().write(msgBuffer4);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Toast.makeText(getBaseContext(), Long.toString(epochTime), Toast.LENGTH_SHORT).show();
			}

		});

		btnCollect.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				long epochTime = System.currentTimeMillis();
				ByteBuffer buffer = ByteBuffer.allocate(8);
				buffer.putLong(epochTime);
				int[] packetPart1 = {0, 4, 0, 0};
				int[] packetPart2 = {0, 0, 0, 0}; //16bit length (in this case its saying 3 bytes), 16 bit reserved
				int[] packetPart3 = {buffer.get(0), buffer.get(1), buffer.get(2), buffer.get(3)}; //16bit length (in this case its saying 3 bytes), 16 bit reserved
				int[] packetPart4 = {buffer.get(4), buffer.get(5), buffer.get(6), buffer.get(7)}; //16bit length (in this case its saying 3 bytes), 16 bit reserved
				byte[] msgBuffer1 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer1[i] = (byte)packetPart1[i];
				}
				byte[] msgBuffer2 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer2[i] = (byte)packetPart2[i];
				}
				byte[] msgBuffer3 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer3[i] = (byte)packetPart3[i];
				}
				byte[] msgBuffer4 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer4[i] = (byte)packetPart4[i];
				}
				try {
					mBTSocket.getOutputStream().write(msgBuffer1);
					mBTSocket.getOutputStream().write(msgBuffer2);
					mBTSocket.getOutputStream().write(msgBuffer3);
					mBTSocket.getOutputStream().write(msgBuffer4);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Toast.makeText(getBaseContext(), "Sync Time", Toast.LENGTH_SHORT).show();
			}
		});

		btnStop.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				int[] sleepPacketPart1 = {0x00, 0x03, 0x00, 0x00}; //Version 0, Type 1 - DataRequest, Checksum, Reserved
				int[] sleepPacketPart2 = {0x00, 0x00, 0x00, 0x00}; //16bit length (in this case its saying 3 bytes), 16 bit reserved
				byte[] msgBuffer1 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer1[i] = (byte)sleepPacketPart1[i];
				}
				byte[] msgBuffer2 = new byte[4];
				for(int i=0; i<4; i++){
					msgBuffer2[i] = (byte)sleepPacketPart2[i];
				}
				try {
					mBTSocket.getOutputStream().write(msgBuffer1);
					mBTSocket.getOutputStream().write(msgBuffer2);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Toast.makeText(getBaseContext(), "Sleep", Toast.LENGTH_SHORT).show();
			}
		});


		btnServer.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				makeCSV();
				HttpURLConnection connection = null;
				DataOutputStream outputStream = null;
				DataInputStream inputStream = null;
				String pathToOurFile = "/download/output.csv";
				String urlServer = "http://teammdc.ddns.net/upload";
				String lineEnd = "\r\n";
				String twoHyphens = "--";
				String boundary =  "*****";
				File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "output.csv");
				file.getName();
				int serverResponseCode = 0;
				String serverResponseMessage = "";
				FileInputStream fileInputStream;
				int bytesRead, bytesAvailable, bufferSize;
				byte[] buffer;
				int maxBufferSize = 1*1024*1024;

				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy);

				try
				{
					fileInputStream = new FileInputStream(file);
					Log.i("Server", "After inputstream");
					URL url = new URL(urlServer);
					connection = (HttpURLConnection) url.openConnection();

					// Allow Inputs &amp; Outputs.
					connection.setDoInput(true);
					connection.setDoOutput(true);
					connection.setUseCaches(false);

					// Set HTTP method to POST.
					connection.setRequestMethod("POST");

					connection.setRequestProperty("Connection", "Keep-Alive");
					connection.setRequestProperty("Content-Type", "multipart/form-data;boundary="+boundary);

					outputStream = new DataOutputStream( connection.getOutputStream() );
					outputStream.writeBytes(twoHyphens + boundary + lineEnd);
					outputStream.writeBytes("Content-Disposition: form-data; name=\"file\";filename=\"" + file.getName() + "\"" + lineEnd);
					outputStream.writeBytes(lineEnd);


					bytesAvailable = fileInputStream.available();
					bufferSize = Math.min(bytesAvailable, maxBufferSize);
					buffer = new byte[bufferSize];

					// Read file
					bytesRead = fileInputStream.read(buffer, 0, bufferSize);

					while (bytesRead > 0)
					{
						outputStream.write(buffer, 0, bufferSize);
						bytesAvailable = fileInputStream.available();
						bufferSize = Math.min(bytesAvailable, maxBufferSize);
						bytesRead = fileInputStream.read(buffer, 0, bufferSize);
					}

					outputStream.writeBytes(lineEnd);
					outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

					// Responses from the server (code and message)
					serverResponseCode = connection.getResponseCode();
					serverResponseMessage = connection.getResponseMessage();

					fileInputStream.close();
					outputStream.flush();
					outputStream.close();
				}
				catch (Exception ex)
				{
					Log.e("Server Exception", "Thrown", ex);
                    Log.i("send", "error");
				}

				final String strInput = serverResponseMessage;
				Log.i("server", serverResponseMessage);
			}
		});
	}


	private class ReadInput implements Runnable {

		private boolean bStop = false;
		private Thread t;

		public ReadInput() {
			t = new Thread(this, "Input Thread");
			t.start();
		}
		public boolean isRunning() {
			return t.isAlive();
		}

		@Override
		public void run() {
			InputStream inputStream;
			try {
				InputStream buf = mBTSocket.getInputStream();//inputStream = ;
				while (!bStop) {
					String fsr1 ="";
					String fsr2 ="";
					String fsr3 ="";
					String fsr4 ="";
					String ax ="";
					String ay ="";
					String az ="";
					String gx ="";
					String gy ="";
					String gz ="";
					String time ="";
                    int v = 0;
					String[] dataSet = new String[880];
					byte[] buffer = new byte[1760];

                    while (buf.available() > 1760) {
                        int siz = buf.available();
						buf.read(buffer, 0, 1760);

						String temp = "";

						int j = 0;

						int i = 0;
                        int setCount = 0;
						long timeStart = System.currentTimeMillis();
						while(i <1760){

							fsr1 = Integer.toString(buffer[i]);
							fsr2= Integer.toString(buffer[i+1]);
							fsr3= Integer.toString(buffer[i+2]);
							fsr4= Integer.toString(buffer[i+3]);
							ax= Integer.toString((short)(buffer[i+4] << 8) | (buffer[i+5] & 0xff));
							ay= Integer.toString((short)(buffer[i+6] << 8) | (buffer[i+7] & 0xff));
							az= Integer.toString((short)(buffer[i+8] << 8) | (buffer[i+9] & 0xff));
							gx= Integer.toString((short)(buffer[i+10] << 8) | (buffer[i+11] & 0xff));
							gy= Integer.toString((short)(buffer[i+12] << 8) | (buffer[i+13] & 0xff));
							gz= Integer.toString((short)(buffer[i+14] << 8) | (buffer[i+15] & 0xff));

							String result1 = Integer.toBinaryString(buffer[i+16] & 0xff);
							String result2 = Integer.toBinaryString(buffer[i+17] & 0xff);
							String result3 = Integer.toBinaryString(buffer[i+18] & 0xff);
							String result4 = Integer.toBinaryString(buffer[i+19] & 0xff);
							String result5 = Integer.toBinaryString(buffer[i+20] & 0xff);
							String result6 = Integer.toBinaryString(buffer[i+21] & 0xff);
							String fix;
							if((Integer.toBinaryString(buffer[i+16] & 0xff).length()) !=8){
								 fix = padZeros((Integer.toBinaryString(buffer[i+16] & 0xff).length()));
								 result1 = fix + result1;
							}
							if((Integer.toBinaryString(buffer[i+17] & 0xff).length()) !=8){
								 fix = padZeros((Integer.toBinaryString(buffer[i+17] & 0xff).length()));
								 result2 = fix + result2;
							}
							if((Integer.toBinaryString(buffer[i+18] & 0xff).length()) !=8){
								 fix = padZeros((Integer.toBinaryString(buffer[i+18] & 0xff).length()));
								 result3 = fix + result3;
							}
							if((Integer.toBinaryString(buffer[i+19] & 0xff).length()) !=8){
								 fix = padZeros((Integer.toBinaryString(buffer[i+19] & 0xff).length()));
								 result4 = fix + result4;
							}
							if((Integer.toBinaryString(buffer[i+20] & 0xff).length()) !=8){
								 fix = padZeros((Integer.toBinaryString(buffer[i+20] & 0xff).length()));
								 result5 = fix + result5;
							}
							if((Integer.toBinaryString(buffer[i+21] & 0xff).length()) !=8){
								 fix = padZeros((Integer.toBinaryString(buffer[i+21] & 0xff).length()));
								 result6 = fix + result6;
							}
							String bin = result1 + result2 + result3 + result4+ result5+ result6;

							BigInteger yourNumber = new BigInteger(bin, 2);
							time = yourNumber.toString();

							dataSet[setCount++] = gx;
                            dataSet[setCount++] = gy;
                            dataSet[setCount++] = gz;
                            dataSet[setCount++] = fsr1;
                            dataSet[setCount++] = fsr2;
                            dataSet[setCount++] = fsr3;
                            dataSet[setCount++] = fsr4;
                            dataSet[setCount++] = ax;
                            dataSet[setCount++] = ay;
                            dataSet[setCount++] = az;
                            dataSet[setCount++] = time;
							Log.i("recieve", time);
                            if(setCount == 880){
                                mydb.bulkInsertOneHundredRecords("patient_table",dataSet, 880);
                                setCount = 0;
                            }
							i=i+22;
						}
						i=0;
					}


					Thread.sleep(500);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		public String padZeros(int length){
			int correct = 8;
			int total = correct - length;
			String fix="";
			for(int i = 0; i<total;i++){
				fix = fix +0;
			}
			return fix;
		}

		public void stop() {
			bStop = true;
		}

	}


	private class DisConnectBT extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
		}

		@Override
		protected Void doInBackground(Void... params) {

			if (mReadThread != null) {
				mReadThread.stop();
				while (mReadThread.isRunning())
					; // Wait until it stops
				mReadThread = null;

			}

			try {
				mBTSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			mIsBluetoothConnected = false;
			if (mIsUserInitiatedDisconnect) {
				finish();
			}
		}

	}

	private void makeCSV(){
		//DatabaseHelper dbh = new DatabaseHelper(context);
		SQLiteDatabase db = mydb.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM patient_table", null);
		FileOutputStream outputStream;

		if (!cursor.moveToFirst()) {
			// something went wrong - bad sql or no results
		}
		File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "output.csv");
		try {
			outputStream = new FileOutputStream(file);

			do {
				// if any of the columns have commas in their values, you will have to do more involved
				// checking here to ensure they are escaped properly in the csv

				// the numbes are column indexes. if you care about the order of the columns in your
				// csv, you may want to move them around

				outputStream.write(deviceAddress.getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("SYNC")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("GX")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("GY")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("GZ")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("AX")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("AY")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("AZ")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("F1")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("F2")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("F3")).getBytes());
				outputStream.write(",".getBytes());
				outputStream.write(cursor.getString(cursor.getColumnIndex("F4")).getBytes());
				outputStream.write("\n".getBytes());
                Log.i("test", "wrote");

			} while (cursor.moveToNext());

			outputStream.flush();
			outputStream.close();

		} catch (Exception e) {

			e.printStackTrace();
		}

		cursor.close();
		db.delete("patient_table", null, null);
	}
	private void msg(String s) {
		Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onPause() {
		if (mBTSocket != null && mIsBluetoothConnected) {
			new DisConnectBT().execute();
		}
		Log.d(TAG, "Paused");
		super.onPause();
	}

	@Override
	protected void onResume() {
		if (mBTSocket == null || !mIsBluetoothConnected) {
			new ConnectBT().execute();
		}
		Log.d(TAG, "Resumed");
		super.onResume();
	}


	@Override
    protected void onStop() {
		Log.d(TAG, "Stopped");
		super.onStop();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
	}

	private class ConnectBT extends AsyncTask<Void, Void, Void> {
		private boolean mConnectSuccessful = true;

		@Override
		protected void onPreExecute() {
			progressDialog = ProgressDialog.show(MainActivity.this, "Hold on", "Connecting");// http://stackoverflow.com/a/11130220/1287554
		}

		@Override
		protected Void doInBackground(Void... devices) {

			try {
				if (mBTSocket == null || !mIsBluetoothConnected) {
					mBTSocket = mDevice.createInsecureRfcommSocketToServiceRecord(mDeviceUUID);
					BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
					mBTSocket.connect();
				}
			} catch (IOException e) {
				// Unable to connect to device
				e.printStackTrace();
				mConnectSuccessful = false;
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);

			if (!mConnectSuccessful) {
				Toast.makeText(getApplicationContext(), "Could not connect to device. Is it a Serial device? Also check if the UUID is correct in the settings", Toast.LENGTH_LONG).show();
				finish();
			} else {
				msg("Connected to device");
				mIsBluetoothConnected = true;
				mReadThread = new ReadInput(); // Kick off input reader
			}

			progressDialog.dismiss();
		}

	}


}
