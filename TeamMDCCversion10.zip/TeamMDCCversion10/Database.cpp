#include "SD.h"
#include "SPI.h"
#include <stdint.h>
#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "Settings.h"
#include "Database.h"

uint8_t Query::execute(uint64_t initialIndex) {
  //Set the database,file and index being used, to the database, file and index in the query object
  Database database = db;
  database.dbFile = SD.open("MDC", FILE_WRITE);
  idx = initialIndex;
  //Count is set which is the number of rows, minus what row we are starting at
  _count = database.count() - initialIndex;
  //That number is also the number of remaining rows it still needs to read
  _remaining = _count;
  return 1;
};

uint64_t Query::count() {
  return _count;
}

volatile uint64_t Query::remaining() {
  return _remaining;
}

volatile uint8_t Query::isEmpty() {
  return _remaining <= 0;
}

Row Query::fetch() {
  //TODO: Add delete after fetch
  //Subtracts a row from reamining, read the next row
  _remaining--;
  Row r = db.readRow(idx++);
  return r;
};


void Database::setError(int error) {
  error = error;
}

int Database::initDatabase() {

  // write default header if no header retrieved
  if (!getHeader()) {
    for (uint8_t i = 0; i < 8; i++) {
      header.signature[i] = 0xFF;
    }
    if (!saveHeader()) return 0;
  }

  return 1;
}

int Database::getHeader() {
  if (((uint64_t) dbFile.size()) <= sizeof(Header)) {
    return 0;
  }
  
  // move to start of file before reading
  dbFile.seek(0);
  
  // read bytes into array
  uint8_t bytes[sizeof(Header)];
  for (uint8_t i = 0; i < sizeof(Header); i++) {
    bytes[i] = dbFile.read();
  }
  
  // check signature
  for (uint8_t j = 0; j < 8; j++) {
    if (bytes[j] != 0xFF) {
      return 0;
    }
  }
  
  // cast bytes as struct
  header = *((Header *) bytes);
  
  return 1;
}

int Database::saveHeader() {
  unsigned char *bytes = (unsigned char *) &header;
  int bytes_written = dbFile.write(bytes, sizeof(Header));
  if (bytes_written != sizeof(Header)) {
    setError(5);
    return 0;
  }
  return 1;
};

int64_t Database::getIndex(uint64_t position) {
  cli();
  
  uint64_t fileSize = dbFile.size();
  
  // check validity of position
  if ((fileSize - sizeof(Header)) % sizeof(Row) != 0) {
    return -1;
  }
  
  sei();
  
  return (fileSize - sizeof(Header)) / sizeof(Row);
}

int Database::getError() {
  return error;
}

int Database::connect(int chipSelect) {
  SPI.setSCK(14);
  if (!SD.begin(chipSelect)) {
    setError(1);
    return 0;
  }
  
  dbFile = SD.open("MDC", FILE_WRITE);
  
  if (!dbFile) {
    setError(2);
    return 0;
  }
  
  if (!initDatabase()) {
    setError(3);
    return 0;
  }
  
  return 1;
};

int Database::disconnect() {
  dbFile.close();
  return 1;
};

void Database::deleteRow(uint64_t index) {
  Serial.println("DELETING ROW");
  Row row;
  //row.timestamp = 
  //unsigned char *bytesNull = (unsigned char *) &row;
  //uint8_t bytes[sizeof(Row)];
  int rowLength = sizeof(Row);
  Serial.println(rowLength);
  unsigned char bytesNULL[rowLength];
  for(int i =0; i < rowLength; i++){
    bytesNULL[i]= NULL;
  }
  
  cli();
  dbFile.seek(sizeof(Header) + index * sizeof(Row));
  for (uint64_t i = 0; i < sizeof(Row); i++) {
    dbFile.write(bytesNULL, sizeof(Row));
  }
  sei();
  // end interrupt protect
  
}


int Database::writeRow(Row row) {
  // interrupt protect
  cli();
  unsigned char *bytes = (unsigned char *) &row;
  dbFile.seek(dbFile.size()); // TODO Optimize this!
  
  if (dbFile.write(bytes, sizeof(Row)) != sizeof(Row)) {
    setError(4);
    return 0;
  }
  
  if (rowsSinceSave++ >= FLUSH_ROWS_AFTER) {
    dbFile.flush();
    rowsSinceSave = 0;
  }
  
  sei();
  // end interrupt protect
  return 1;
};

Row Database::readRow(uint64_t index) {
  uint8_t bytes[sizeof(Row)];
  cli();
  dbFile.seek(sizeof(Header) + index * sizeof(Row));
  for (uint64_t i = 0; i < sizeof(Row); i++) {
    bytes[i] = dbFile.read();
  }
  sei();
  // end interrupt protect
  Row row = *((Row *) bytes);
  
  return row;
}

uint64_t Database::count() {
  int headerSize = sizeof(Header);
  int RowSize = sizeof(Row);
  unsigned long fileSize = dbFile.size();
  return (uint64_t) ((fileSize - headerSize) / RowSize);
}

Query Database::query(uint64_t since) {
  int64_t min = 0;
  int64_t max = (int64_t) count();
  int64_t mid = 0;
  while (min <= max) {
    mid = min + (uint64_t)((max - min) / 2);
    uint64_t timestamp = readRow(mid).timestamp;
    if (timestamp > since) {
      max = mid - 1;
    } else if (timestamp < since) {
    min = mid + 1;
    } else {
      break;
    }
  }
  
  // since duplicate readings per ms are possible...
  while (readRow(mid).timestamp <= since) {
    mid++;
  }
  
  Query q;
  q.execute((uint64_t) mid);
  return q;
};



