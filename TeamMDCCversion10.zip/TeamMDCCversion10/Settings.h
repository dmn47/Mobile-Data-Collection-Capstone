//
// Created by Justin on 2/15/16.
//

#ifndef DATABASE_SETTINGS_H
#define DATABASE_SETTINGS_H

#define FLUSH_ROWS_AFTER 100
#define DATABASE_FILENAME "MDC"
#define CHIP_SELECT 10

#endif //DATABASE_SETTINGS_H
