#ifndef FSR_h
#define FSR_h

int fsrOne = 20;
int fsrTwo = 21;
int fsrThree = 22;
int fsrFour = 23;
#endif //FSR_h
